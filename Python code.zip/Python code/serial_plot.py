import serial
import serial.tools.list_ports
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from collections import deque
import time
import sys

# ---- 1. List available COM ports ----
print("=== Available COM ports ===")
for p in serial.tools.list_ports.comports():
    print(f"{p.device} -> {p.description}")

# ---- 2. Serial setup (use COM9) ----
PORT = 'COM9'
BAUD = 9600

try:
    ser = serial.Serial(PORT, BAUD, timeout=0.1)
    ser.reset_input_buffer()
    print(f"[INFO] Opened serial port {PORT} at {BAUD} baud.")
except serial.SerialException as e:
    print(f"[ERROR] Could not open {PORT}: {e}")
    sys.exit(1)

# ---- 3. Plot setup ----
plt.ion()

# 3D figure
fig1 = plt.figure(1)
ax3d = fig1.add_subplot(111, projection='3d')
line3d, = ax3d.plot([], [], [], 'r.-', markersize=4)
ax3d.set_xlim(-20, 20)
ax3d.set_ylim(-20, 20)
ax3d.set_zlim(-20, 20)
ax3d.set_xlabel('X')
ax3d.set_ylabel('Y')
ax3d.set_zlabel('Z')
ax3d.set_title('Live Accelerometer Data (3D)')

# 2D Time plot
fig2, ax2d = plt.subplots()
line_x, = ax2d.plot([], [], 'r', label='X')
line_y, = ax2d.plot([], [], 'g', label='Y')
line_z, = ax2d.plot([], [], 'b', label='Z')
ax2d.set_xlim(0, 10)
ax2d.set_ylim(-20, 20)
ax2d.set_xlabel('Time (s)')
ax2d.set_ylabel('Acceleration (g)')
ax2d.set_title('Live Accelerometer Data (Time Domain)')
ax2d.legend()
ax2d.grid(True)

plt.show(block=False)

# ---- 4. Buffers & timing ----
buffer = ""
X = deque(maxlen=100)
Y = deque(maxlen=100)
Z = deque(maxlen=100)
T = deque(maxlen=100)
t0 = time.time()

# ---- 5. Main loop ----
while True:
    plt.pause(0.0001)  # very short pause

    if ser.in_waiting:
        raw = ser.read(ser.in_waiting).decode(errors='ignore')
        buffer += raw

        while 'A' in buffer and '*' in buffer:
            start = buffer.find('A')
            end = buffer.find('*', start)
            if end == -1:
                break

            pkt = buffer[start+1:end]
            buffer = buffer[end+1:]

            try:
                nums = list(map(float, pkt.split(',')))
                if len(nums) == 3:
                    x, y, z = nums
                    t = time.time() - t0
                    X.append(x); Y.append(y); Z.append(z); T.append(t)

                    # Update 3D
                    line3d.set_data(X, Y)
                    line3d.set_3d_properties(Z)
                    ax3d.set_title(f'3D Data @ t={t:.1f}s')
                    fig1.canvas.draw_idle()

                    # Update 2D
                    line_x.set_data(T, X)
                    line_y.set_data(T, Y)
                    line_z.set_data(T, Z)
                    ax2d.set_xlim(max(0, T[-1] - 10), T[-1])
                    fig2.canvas.draw_idle()
                else:
                    print(f"[WARN] Packet malformed: {pkt!r}")
            except ValueError:
                print(f"[WARN] Could not parse: {pkt!r}")
